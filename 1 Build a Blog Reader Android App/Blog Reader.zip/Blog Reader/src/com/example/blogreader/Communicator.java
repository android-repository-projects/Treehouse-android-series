package com.example.blogreader;

public interface Communicator {

	public void handleBlogResponse(String result);
}
